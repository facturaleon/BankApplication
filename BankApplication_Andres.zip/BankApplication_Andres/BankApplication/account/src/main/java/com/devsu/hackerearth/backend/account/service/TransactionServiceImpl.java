package com.devsu.hackerearth.backend.account.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {
    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    @Autowired
    public TransactionServiceImpl(TransactionRepository transactionRepository, AccountRepository accountRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
    }

    /** Constructor retained for unit tests that only exercise transaction listing/lookup. */
    public TransactionServiceImpl(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = null;
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> getAll() {
        return transactionRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public TransactionDto getById(Long id) {
        return toDto(transactionRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Movimiento no encontrado: " + id)));
    }

    @Override
    public TransactionDto create(TransactionDto dto) {
        if (dto == null || dto.getAccountId() == null)
            throw new IllegalArgumentException("El id de la cuenta es obligatorio");
        Account account = accountRepository.findById(dto.getAccountId())
            .orElseThrow(() -> new IllegalArgumentException("Cuenta no encontrada: " + dto.getAccountId()));
        if (!account.isActive()) throw new IllegalArgumentException("La cuenta está inactiva");

        double amount = dto.getAmount();
        double currentBalance = transactionRepository
            .findFirstByAccountIdOrderByDateDescIdDesc(account.getId())
            .map(Transaction::getBalance).orElse(account.getInitialAmount());
        double newBalance = currentBalance + amount;
        if (newBalance < 0) throw new IllegalArgumentException("Saldo no disponible");

        Transaction tx = new Transaction();
        tx.setDate(dto.getDate() == null ? new Date() : dto.getDate());
        tx.setType(dto.getType() == null || dto.getType().trim().isEmpty()
            ? (amount < 0 ? "Retiro" : "Depósito") : dto.getType());
        tx.setAmount(amount);
        tx.setBalance(newBalance);
        tx.setAccountId(account.getId());
        return toDto(transactionRepository.save(tx));
    }

    @Override
    @Transactional(readOnly = true)
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date start, Date end) {
        if (clientId == null || start == null || end == null)
            throw new IllegalArgumentException("Cliente y rango de fechas son obligatorios");
        if (start.after(end)) throw new IllegalArgumentException("La fecha inicial no puede ser posterior a la final");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(end);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        Date inclusiveEnd = calendar.getTime();

        List<Account> accounts = accountRepository.findByClientId(clientId);
        return accounts.stream().flatMap(account ->
            transactionRepository.findByAccountIdAndDateBetweenOrderByDateAsc(account.getId(), start, inclusiveEnd)
                .stream().map(tx -> new BankStatementDto(
                    tx.getDate(), String.valueOf(clientId), account.getNumber(), account.getType(),
                    account.getInitialAmount(), account.isActive(), tx.getType(), tx.getAmount(), tx.getBalance()
                ))
        ).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public TransactionDto getLastByAccountId(Long accountId) {
        return transactionRepository.findFirstByAccountIdOrderByDateDescIdDesc(accountId)
            .map(this::toDto).orElse(null);
    }

    private TransactionDto toDto(Transaction tx) {
        return new TransactionDto(tx.getId(), tx.getDate(), tx.getType(), tx.getAmount(), tx.getBalance(), tx.getAccountId());
    }
}
