package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {
    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<AccountDto> getAll() {
        return accountRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public AccountDto getById(Long id) {
        return toDto(findAccount(id));
    }

    @Override
    public AccountDto create(AccountDto dto) {
        if (dto == null) throw new IllegalArgumentException("La cuenta es obligatoria");
        Account account = new Account();
        apply(account, dto);
        return toDto(accountRepository.save(account));
    }

    @Override
    public AccountDto update(AccountDto dto) {
        if (dto == null || dto.getId() == null) throw new IllegalArgumentException("El id de la cuenta es obligatorio");
        Account account = findAccount(dto.getId());
        apply(account, dto);
        return toDto(accountRepository.save(account));
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto dto) {
        if (dto == null) throw new IllegalArgumentException("Los datos son obligatorios");
        Account account = findAccount(id);
        account.setActive(dto.isActive());
        return toDto(accountRepository.save(account));
    }

    @Override
    public void deleteById(Long id) {
        Account account = findAccount(id);
        accountRepository.delete(account);
    }

    private Account findAccount(Long id) {
        return accountRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Cuenta no encontrada: " + id));
    }

    private void apply(Account account, AccountDto dto) {
        account.setNumber(dto.getNumber());
        account.setType(dto.getType());
        account.setInitialAmount(dto.getInitialAmount());
        account.setActive(dto.isActive());
        account.setClientId(dto.getClientId());
    }

    private AccountDto toDto(Account a) {
        return new AccountDto(a.getId(), a.getNumber(), a.getType(), a.getInitialAmount(), a.isActive(), a.getClientId());
    }
}
