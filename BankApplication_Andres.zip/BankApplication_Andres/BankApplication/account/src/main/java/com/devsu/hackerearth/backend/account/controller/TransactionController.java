package com.devsu.hackerearth.backend.account.controller;

import java.util.Date;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.service.TransactionService;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {
    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) { this.transactionService = transactionService; }

    @GetMapping
    public ResponseEntity<List<TransactionDto>> getAll() { return ResponseEntity.ok(transactionService.getAll()); }

    @GetMapping("/{id}")
    public ResponseEntity<TransactionDto> get(@PathVariable Long id) { return ResponseEntity.ok(transactionService.getById(id)); }

    @PostMapping
    public ResponseEntity<TransactionDto> create(@RequestBody TransactionDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(transactionService.create(dto));
    }

    @GetMapping("/clients/{clientId}/report")
    public ResponseEntity<List<BankStatementDto>> report(
        @PathVariable Long clientId,
        @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateTransactionStart,
        @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateTransactionEnd) {
        return ResponseEntity.ok(transactionService.getAllByAccountClientIdAndDateBetween(
            clientId, dateTransactionStart, dateTransactionEnd));
    }
}
