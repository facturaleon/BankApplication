package com.devsu.hackerearth.backend.client.controller;

import java.util.Collections;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class RestExceptionHandler {
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleBadRequest(IllegalArgumentException ex) {
        HttpStatus status = ex.getMessage() != null &&
            (ex.getMessage().startsWith("Cliente no encontrado") || ex.getMessage().startsWith("Cuenta no encontrada"))
            ? HttpStatus.NOT_FOUND : HttpStatus.BAD_REQUEST;
        return ResponseEntity.status(status).body(Collections.singletonMap("mensaje", ex.getMessage()));
    }
}
