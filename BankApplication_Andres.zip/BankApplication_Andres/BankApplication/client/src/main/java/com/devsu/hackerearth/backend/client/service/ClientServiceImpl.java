package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
@Transactional
public class ClientServiceImpl implements ClientService {
    private final ClientRepository clientRepository;

    public ClientServiceImpl(ClientRepository clientRepository) { this.clientRepository = clientRepository; }

    @Override
    @Transactional(readOnly = true)
    public List<ClientDto> getAll() {
        return clientRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public ClientDto getById(Long id) { return toDto(findClient(id)); }

    @Override
    public ClientDto create(ClientDto dto) {
        if (dto == null) throw new IllegalArgumentException("El cliente es obligatorio");
        Client client = new Client();
        apply(client, dto);
        return toDto(clientRepository.save(client));
    }

    @Override
    public ClientDto update(ClientDto dto) {
        if (dto == null || dto.getId() == null) throw new IllegalArgumentException("El id del cliente es obligatorio");
        Client client = findClient(dto.getId());
        apply(client, dto);
        return toDto(clientRepository.save(client));
    }

    @Override
    public ClientDto partialUpdate(Long id, PartialClientDto dto) {
        if (dto == null) throw new IllegalArgumentException("Los datos son obligatorios");
        Client client = findClient(id);
        client.setActive(dto.isActive());
        return toDto(clientRepository.save(client));
    }

    @Override
    public void deleteById(Long id) { clientRepository.delete(findClient(id)); }

    private Client findClient(Long id) {
        return clientRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado: " + id));
    }

    private void apply(Client c, ClientDto dto) {
        c.setDni(dto.getDni());
        c.setName(dto.getName());
        c.setPassword(dto.getPassword());
        c.setGender(dto.getGender());
        c.setAge(dto.getAge());
        c.setAddress(dto.getAddress());
        c.setPhone(dto.getPhone());
        c.setActive(dto.isActive());
    }

    private ClientDto toDto(Client c) {
        return new ClientDto(c.getId(), c.getDni(), c.getName(), c.getPassword(), c.getGender(),
            c.getAge(), c.getAddress(), c.getPhone(), c.isActive());
    }
}
